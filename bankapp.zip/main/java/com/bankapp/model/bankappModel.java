package com.bankapp.model;

public class bankappModel{

private int accNumber;
private int accBalance;
private int depositAmount;
private int withdrawAmount; 
private String customerId;
private String customerName;
private String accPassword;
public int getAccNumber() {
	return accNumber;
}
public void setAccNumber(int accNumber) {
	this.accNumber = accNumber;
}
public int getAccBalance() {
	return accBalance;
}
public void setAccBalance(int accBalance) {
	this.accBalance = accBalance;
}
public int getDepositAmount() {
	return depositAmount;
}
public void setDepositAmount(int depositAmount) {
	this.accBalance += depositAmount;
}
public int getWithdrawAmount() {
	return withdrawAmount;
}
public void setWithdrawAmount(int withdrawAmount) {
	this.withdrawAmount -= withdrawAmount;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getAccPassword() {
	return accPassword;
}
public void setAccPassword(String accPassword) {
	this.accPassword = accPassword;
}

}



